// Quiz question banks for MIL Academy
// Each question: { q: string, options: string[], correct: number (index) }

const QUIZZES = {
  foundations: {
    id: 'foundations',
    title: 'Media Literacy Basics',
    timeLimitSeconds: 12 * 60,
    questions: [
      {
        q: "What is the primary goal of Media and Information Literacy (MIL)?",
        options: [
          "To teach people how to create viral content",
          "To empower citizens to engage critically with media and information",
          "To promote specific political viewpoints through media",
          "To replace traditional journalism education"
        ],
        correct: 1
      },
      {
        q: "According to UNESCO, which of the following is a core MIL competency?",
        options: [
          "Memorizing the names of major media conglomerates",
          "Understanding how media and information are produced, financed, and distributed",
          "Avoiding all forms of social media",
          "Learning advanced video editing software"
        ],
        correct: 1
      },
      {
        q: "The idea that media can shape public perception and behavior is most closely associated with which concept?",
        options: [
          "Media effects",
          "Net neutrality",
          "Open-source software",
          "Digital divide"
        ],
        correct: 0
      },
      {
        q: "Why is media literacy considered essential in democratic societies?",
        options: [
          "It guarantees that all citizens will agree on the news",
          "It helps citizens make informed decisions and participate meaningfully",
          "It eliminates the need for professional journalists",
          "It ensures governments control the flow of information"
        ],
        correct: 1
      },
      {
        q: "What does the term 'media diet' refer to in media literacy education?",
        options: [
          "A strict limit on screen time for children",
          "The types and sources of media a person regularly consumes",
          "Government-approved lists of news outlets",
          "A diet plan advertised through social media influencers"
        ],
        correct: 1
      },
      {
        q: "Which of the following best describes 'information literacy'?",
        options: [
          "The ability to use search engines quickly",
          "The ability to recognize when information is needed and to locate, evaluate, and use it effectively",
          "Knowing how to code websites",
          "Memorizing facts from textbooks"
        ],
        correct: 1
      },
      {
        q: "Media literacy education typically encourages students to ask which of the following questions about a message?",
        options: [
          "Who created this and why?",
          "How many likes does it have?",
          "Is it trending on social media?",
          "Does it match my personal beliefs?"
        ],
        correct: 0
      },
      {
        q: "What is a key difference between media literacy and simply being 'media savvy'?",
        options: [
          "Media literacy focuses on critical analysis and ethical reflection, not just technical skill",
          "Media savvy people never need education",
          "Media literacy only applies to traditional print media",
          "There is no meaningful difference"
        ],
        correct: 0
      }
    ]
  },

  evaluation: {
    id: 'evaluation',
    title: 'Evaluating Sources & News',
    timeLimitSeconds: 15 * 60,
    questions: [
      {
        q: "What does the SIFT method stand for in evaluating online information?",
        options: [
          "Search, Investigate, Find, Trust",
          "Stop, Investigate the source, Find better coverage, Trace claims",
          "Scan, Identify, Fact-check, Tell others",
          "Source, Integrity, Fact, Transparency"
        ],
        correct: 1
      },
      {
        q: "Lateral reading means:",
        options: [
          "Reading every word on a webpage from top to bottom",
          "Opening new tabs to research a source or claim across other sites",
          "Reading only the headlines of multiple articles",
          "Comparing the length of different articles"
        ],
        correct: 1
      },
      {
        q: "What is the main difference between misinformation and disinformation?",
        options: [
          "Misinformation is always visual; disinformation is always text",
          "Misinformation is false information shared without intent to harm; disinformation is deliberately deceptive",
          "There is no difference; the terms are interchangeable",
          "Disinformation is only spread by governments"
        ],
        correct: 1
      },
      {
        q: "The CRAAP test evaluates sources based on Currency, Relevance, Authority, Accuracy, and:",
        options: [
          "Popularity",
          "Purpose",
          "Presentation",
          "Platform"
        ],
        correct: 1
      },
      {
        q: "When evaluating a news story, why is checking the original source of a claim important?",
        options: [
          "Original sources are always correct",
          "Claims are often taken out of context or distorted as they are reshared",
          "Only original sources can be copyrighted",
          "It helps you find the longest version of the story"
        ],
        correct: 1
      },
      {
        q: "Which of the following is a red flag that a social media post may be unreliable?",
        options: [
          "It includes a link to a primary source document",
          "It uses highly emotional language and urges immediate sharing without verification",
          "It is published by a well-known news organization",
          "It cites multiple independent experts"
        ],
        correct: 1
      },
      {
        q: "What does 'confirmation bias' mean in the context of media consumption?",
        options: [
          "The tendency to seek out and favor information that confirms existing beliefs",
          "The practice of confirming sources with multiple outlets",
          "A bias that only professional journalists have",
          "The bias introduced by media ownership"
        ],
        correct: 0
      },
      {
        q: "Why is reverse image search a useful verification tool?",
        options: [
          "It always identifies the exact location of a photo",
          "It can reveal whether an image is being reused out of context or from an unrelated event",
          "It improves image quality",
          "It is required by law before sharing photos"
        ],
        correct: 1
      },
      {
        q: "A website’s domain ends in .edu. Does this guarantee the content is accurate and unbiased?",
        options: [
          "Yes — educational institutions cannot publish false information",
          "No — individual pages, student projects, or opinion pieces may still be flawed or biased",
          "Yes, but only if the page is linked from the university homepage",
          "No, because .edu domains are no longer restricted"
        ],
        correct: 1
      },
      {
        q: "What is 'framing' in news coverage?",
        options: [
          "The physical layout of a newspaper page",
          "The way a story is presented, including what is emphasized, omitted, or given context",
          "The process of putting a photo in a decorative border",
          "A legal requirement for all news stories"
        ],
        correct: 1
      }
    ]
  },

  ai: {
    id: 'ai',
    title: 'AI, Deepfakes & Digital Trust',
    timeLimitSeconds: 12 * 60,
    questions: [
      {
        q: "What is a 'deepfake'?",
        options: [
          "Any video that has been edited with basic filters",
          "Synthetic media in which a person’s likeness is convincingly replaced or manipulated using AI",
          "A very low-resolution video file",
          "A news story that turns out to be false"
        ],
        correct: 1
      },
      {
        q: "Why can generative AI make media literacy more challenging?",
        options: [
          "AI tools are illegal in most countries",
          "It can produce realistic text, images, and audio at scale, making verification harder",
          "AI always produces factually correct content",
          "People no longer need to read news"
        ],
        correct: 1
      },
      {
        q: "What is one recommended practice when encountering suspicious AI-generated content?",
        options: [
          "Immediately share it to warn others",
          "Look for provenance information, watermarks, or use reverse search and multiple sources",
          "Assume everything online is AI-generated",
          "Only trust content that has no images"
        ],
        correct: 1
      },
      {
        q: "Algorithmic curation on social platforms tends to:",
        options: [
          "Show every user the exact same content",
          "Prioritize engagement, which can amplify emotionally charged or polarizing material",
          "Guarantee that only verified news appears",
          "Eliminate filter bubbles by design"
        ],
        correct: 1
      },
      {
        q: "What does 'AI literacy' add to traditional media literacy?",
        options: [
          "The ability to write machine learning code",
          "Understanding how AI systems generate, select, and influence information and media",
          "Learning to replace all human journalists with AI",
          "Memorizing the names of every large language model"
        ],
        correct: 1
      },
      {
        q: "Which of the following is a limitation of current AI detection tools?",
        options: [
          "They are 100% accurate on all content",
          "They can produce false positives and false negatives and may lag behind new generation techniques",
          "They only work on text, never images",
          "They require a paid subscription to function at all"
        ],
        correct: 1
      },
      {
        q: "What is the purpose of content provenance standards (such as C2PA)?",
        options: [
          "To prevent anyone from editing photos",
          "To attach verifiable information about how and when digital content was created or modified",
          "To automatically delete deepfakes",
          "To rank search results by popularity"
        ],
        correct: 1
      },
      {
        q: "A healthy response to the rise of synthetic media includes:",
        options: [
          "Trusting nothing online and withdrawing from digital life",
          "Developing stronger verification habits, supporting provenance tools, and maintaining critical thinking",
          "Banning all generative AI tools immediately",
          "Assuming AI-generated content is always superior to human-created content"
        ],
        correct: 1
      }
    ]
  }
};
